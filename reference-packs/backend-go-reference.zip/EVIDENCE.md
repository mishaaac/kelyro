# Curriculum Evidence Report

Goal: Backend engineering with Go (development reference) (`goal.backend-go-reference`)
Domain: backend engineering

## Summary

- Competencies: 5
- Concepts: 9
- Source bundles: 1
- Primary-source coverage: 9/9 (100.0%)
- Compiler: `curriculum-compiler-v1`

## Competencies

- `competency.backend-go.build` — Service construction and verification, apply, 2 concepts
- `competency.backend-go.debug` — Service construction and verification, analyze, 1 concepts
- `competency.backend-go.foundations` — Foundations and Go workspace, understand, 3 concepts
- `competency.backend-go.operate` — Production operations, operate, 2 concepts
- `competency.backend-go.security` — Service security, analyze, 1 concepts

## Sources and freshness

- `bundle.backend-go-reference.dev-v1` — fresh (1.00), policy `fixture-freshness-v1`

## Evidence references

- `bundle.backend-go-reference.dev-v1#claim.backend-go.deployment`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.gopath`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.handlers`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.modules`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.observability`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.terminal`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.tests`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.threats`
- `bundle.backend-go-reference.dev-v1#claim.backend-go.transactions`

## Citations

- [Official Go documentation](<https://go.dev/doc/>) (`source.backend-go-reference`)

## Conflicts and caveats

- Caveat in `bundle.backend-go-reference.dev-v1`: Development fixture only; replace with production I-03 Source Bundles before claiming professional completeness.

## Historical and experimental content

- `concept.backend-go.gopath` — legacy

## Gaps

None.

## Compiler passes

- `validate-input`: `curriculum-compiler-v1`
- `goal-decomposition`: `goal-decomposer-v1`
- `competency-matrix`: `competency-matrix-v1`
- `concept-candidates`: `claim-to-concept-candidates-v1`
- `atomize`: `atomizer-v1`
- `granularity`: `granularity-guard-v1`
- `prerequisite-extraction`: `prerequisite-extractor-v1`
- `prerequisite-expansion`: `prerequisite-expansion-v1`
- `vocabulary-graph`: `vocabulary-graph-v1`
- `knowledge-graph`: `knowledge-graph-compiler-v1`
- `hierarchy`: `curriculum-hierarchy-builder-v2`
- `coverage`: `coverage-v1`
- `definition-before-use`: `definition-before-use-v1`
- `zero-assumption`: `zero-assumption-v1`
- `temporal-classification`: `temporal-classification-v1`
- `guidance-classification`: `guidance-classifier-v1`
- `gap-scan`: `gap-scanner-v1`
- `beginner-simulation`: `beginner-simulation-v1`
- `expert-coverage-review`: `expert-coverage-review-v1`
- `final-review`: `curriculum-reviewer-v1`
- `compiled-artifact`: `curriculum-compiler-v1`
